package com.DuelingFates.Main;

public class Main {

    public static void main(String[] args){

        new MainProcess();                      //MainProccess() egy példányát létrehozzuk

    }

}
